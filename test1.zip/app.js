// Initial Mock Data
let assets = [
    { id: 1, name: '신한은행 주거래 예금', type: 'cash', value: 18500000, date: '2026-07-10' },
    { id: 2, name: '삼성전자 (우)', type: 'stock', value: 24500000, date: '2026-07-12' },
    { id: 3, name: '애플 (AAPL)', type: 'stock', value: 15800000, date: '2026-07-14' },
    { id: 4, name: '마포 아파트 보증금', type: 'real', value: 250000000, date: '2026-07-01' },
    { id: 5, name: '이더리움 (ETH)', type: 'crypto', value: 8700000, date: '2026-07-15' }
];

// 6 Months Historical Wealth (Mock Data for Line Chart)
const months = ['2월', '3월', '4월', '5월', '6월', '7월'];
let historicalWealth = [285000000, 292000000, 305000000, 298000000, 312000000, 317500000];

// Chart Instances
let portfolioChart = null;
let trendChart = null;

// Currency Formatter
const formatCurrency = (value) => {
    return new Intl.NumberFormat('ko-KR', { style: 'currency', currency: 'KRW' }).format(value);
};

// DOM Elements
const totalAssetEl = document.getElementById('totalAsset');
const cashAssetEl = document.getElementById('cashAsset');
const stockAssetEl = document.getElementById('stockAsset');
const realAssetEl = document.getElementById('realAsset');
const cryptoAssetEl = document.getElementById('cryptoAsset');

const cashRatioEl = document.getElementById('cashRatio');
const stockRatioEl = document.getElementById('stockRatio');
const realRatioEl = document.getElementById('realRatio');
const cryptoRatioEl = document.getElementById('cryptoRatio');

const historyListEl = document.getElementById('historyList');
const openModalBtn = document.getElementById('openModalBtn');
const closeModalBtn = document.getElementById('closeModalBtn');
const modalOverlay = document.getElementById('modalOverlay');
const assetForm = document.getElementById('assetForm');

// Initialize Dashboard
function initDashboard() {
    updateDashboardData();
    initCharts();
    renderHistory();
    feather.replace();
}

// Calculate and Update Dashboard Data Cards
function updateDashboardData() {
    let cashTotal = 0;
    let stockTotal = 0;
    let realTotal = 0;
    let cryptoTotal = 0;

    assets.forEach(asset => {
        if (asset.type === 'cash') cashTotal += asset.value;
        else if (asset.type === 'stock') stockTotal += asset.value;
        else if (asset.type === 'real') realTotal += asset.value;
        else if (asset.type === 'crypto') cryptoTotal += asset.value;
    });

    const totalAsset = cashTotal + stockTotal + realTotal + cryptoTotal;

    // Set Text Values
    totalAssetEl.textContent = formatCurrency(totalAsset);
    cashAssetEl.textContent = formatCurrency(cashTotal);
    stockAssetEl.textContent = formatCurrency(stockTotal);
    realAssetEl.textContent = formatCurrency(realTotal);
    cryptoAssetEl.textContent = formatCurrency(cryptoTotal);

    // Calculate Percentages
    const calcPercentage = (val) => totalAsset > 0 ? Math.round((val / totalAsset) * 100) : 0;
    
    cashRatioEl.textContent = `${calcPercentage(cashTotal)}%`;
    stockRatioEl.textContent = `${calcPercentage(stockTotal)}%`;
    realRatioEl.textContent = `${calcPercentage(realTotal)}%`;
    cryptoRatioEl.textContent = `${calcPercentage(cryptoTotal)}%`;

    // Update Line Chart's latest month value
    historicalWealth[historicalWealth.length - 1] = totalAsset;
}

// Render Asset History List
function renderHistory() {
    historyListEl.innerHTML = '';
    
    // Sort assets by date descending
    const sortedAssets = [...assets].sort((a, b) => new Date(b.date) - new Date(a.date));

    sortedAssets.forEach(asset => {
        const item = document.createElement('div');
        item.className = 'history-item';
        
        let typeClass = '';
        let typeLabel = '';
        let iconName = '';

        switch(asset.type) {
            case 'cash':
                typeClass = 'icon-cash-bg';
                typeLabel = '현금';
                iconName = 'dollar-sign';
                break;
            case 'stock':
                typeClass = 'icon-stock-bg';
                typeLabel = '주식';
                iconName = 'trending-up';
                break;
            case 'real':
                typeClass = 'icon-real-bg';
                typeLabel = '부동산';
                iconName = 'home';
                break;
            case 'crypto':
                typeClass = 'icon-crypto-bg';
                typeLabel = '암호화폐';
                iconName = 'cpu';
                break;
        }

        item.innerHTML = `
            <div class="item-left">
                <div class="item-icon-wrapper ${typeClass}">
                    <i data-feather="${iconName}"></i>
                </div>
                <div class="item-info">
                    <h4>${asset.name}</h4>
                    <span>${asset.date}</span>
                </div>
            </div>
            <div class="item-right">
                <div class="item-amount">${formatCurrency(asset.value)}</div>
                <div class="item-category">${typeLabel}</div>
            </div>
        `;
        
        historyListEl.appendChild(item);
    });
    
    feather.replace();
}

// Initialize Charts
function initCharts() {
    // 1. Doughnut Chart (Portfolio Dist)
    const ctxPortfolio = document.getElementById('portfolioChart').getContext('2d');
    
    // Get values
    const dataValues = getCategoryTotals();

    portfolioChart = new Chart(ctxPortfolio, {
        type: 'doughnut',
        data: {
            labels: ['현금', '주식', '부동산', '암호화폐'],
            datasets: [{
                data: dataValues,
                backgroundColor: [
                    '#10b981', // Green
                    '#3b82f6', // Blue
                    '#f59e0b', // Yellow
                    '#8b5cf6'  // Purple
                ],
                borderWidth: 0,
                hoverOffset: 10
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        color: '#94a3b8',
                        font: {
                            family: 'Outfit',
                            size: 11
                        },
                        padding: 15
                    }
                }
            },
            cutout: '70%'
        }
    });

    // 2. Line Chart (Trend)
    const ctxTrend = document.getElementById('trendChart').getContext('2d');
    
    // Gradient background for Line
    const gradient = ctxTrend.createLinearGradient(0, 0, 0, 300);
    gradient.addColorStop(0, 'rgba(139, 92, 246, 0.4)');
    gradient.addColorStop(1, 'rgba(139, 92, 246, 0)');

    trendChart = new Chart(ctxTrend, {
        type: 'line',
        data: {
            labels: months,
            datasets: [{
                label: '총 자산 추이',
                data: historicalWealth,
                fill: true,
                backgroundColor: gradient,
                borderColor: '#8b5cf6',
                borderWidth: 3,
                pointBackgroundColor: '#3b82f6',
                pointBorderColor: '#ffffff',
                pointBorderWidth: 2,
                pointRadius: 5,
                pointHoverRadius: 7,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.05)',
                        drawBorder: false
                    },
                    ticks: {
                        color: '#94a3b8',
                        font: {
                            family: 'Inter',
                            size: 10
                        }
                    }
                },
                y: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.05)',
                        drawBorder: false
                    },
                    ticks: {
                        color: '#94a3b8',
                        font: {
                            family: 'Inter',
                            size: 10
                        },
                        callback: function(value) {
                            return (value / 100000000).toFixed(1) + '억';
                        }
                    }
                }
            }
        }
    });
}

// Get array of category sums
function getCategoryTotals() {
    let cashTotal = 0, stockTotal = 0, realTotal = 0, cryptoTotal = 0;
    
    assets.forEach(asset => {
        if (asset.type === 'cash') cashTotal += asset.value;
        else if (asset.type === 'stock') stockTotal += asset.value;
        else if (asset.type === 'real') realTotal += asset.value;
        else if (asset.type === 'crypto') cryptoTotal += asset.value;
    });

    return [cashTotal, stockTotal, realTotal, cryptoTotal];
}

// Update Charts
function updateCharts() {
    if (portfolioChart && trendChart) {
        portfolioChart.data.datasets[0].data = getCategoryTotals();
        portfolioChart.update();

        trendChart.data.datasets[0].data = historicalWealth;
        trendChart.update();
    }
}

// Modal Handlers
openModalBtn.addEventListener('click', () => {
    modalOverlay.classList.add('active');
    document.getElementById('assetName').focus();
});

closeModalBtn.addEventListener('click', closeModal);
modalOverlay.addEventListener('click', (e) => {
    if (e.target === modalOverlay) closeModal();
});

function closeModal() {
    modalOverlay.classList.remove('active');
    assetForm.reset();
}

// Form Submission (Add new asset)
assetForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const name = document.getElementById('assetName').value;
    const type = document.getElementById('assetType').value;
    const value = parseInt(document.getElementById('assetValue').value);
    const date = new Date().toISOString().split('T')[0]; // Current date YYYY-MM-DD

    if (!name || isNaN(value)) return;

    // Add to assets list
    const newAsset = {
        id: assets.length + 1,
        name,
        type,
        value,
        date
    };
    
    assets.push(newAsset);

    // Refresh Dashboard
    updateDashboardData();
    updateCharts();
    renderHistory();
    closeModal();
});

// Run Init
document.addEventListener('DOMContentLoaded', initDashboard);
